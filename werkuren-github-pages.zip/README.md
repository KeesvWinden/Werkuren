# Werkuren-app online zetten met GitHub Pages

Dit pakket is klaar om te publiceren. Alle bestanden horen **in de hoofdmap
van de repository**, niet in een submap.

De app is gebouwd voor een repository die **`werkuren`** heet, dus het adres
wordt:

    https://<jouw-gebruikersnaam>.github.io/werkuren/

---

## Stap 1 — Repository aanmaken

Ga naar https://github.com/new en maak een repository met de naam **`werkuren`**.

- Zet hem op **Public** (Pages werkt op de gratis versie alleen voor publieke repo's).
- Vink *Add a README* **niet** aan — je krijgt hier alles kant-en-klaar.

## Stap 2 — Bestanden uploaden

De makkelijkste manier, zonder Git:

1. Pak `werkuren-github-pages.zip` uit op je computer.
2. Open de nieuwe repository in je browser.
3. Klik op **Add file → Upload files**.
4. Sleep **alle** uitgepakte bestanden en mappen in het venster.
   Let op: ook de verborgen map `.nojekyll` en de mappen `assets`,
   `canvaskit` en `icons` moeten mee.
5. Klik onderaan op **Commit changes**.

Met Git vanaf de opdrachtregel kan het ook:

    git clone https://github.com/<gebruikersnaam>/werkuren.git
    cd werkuren
    # pak hier de zip inhoud uit
    git add -A
    git commit -m "Werkuren-app online"
    git push

## Stap 3 — Pages aanzetten

1. Ga in de repository naar **Settings** (bovenaan).
2. Kies links **Pages**.
3. Onder *Build and deployment* → *Source*: kies **Deploy from a branch**.
4. Bij *Branch*: kies **main** en map **/ (root)**.
5. Klik **Save**.

Wacht een minuut of twee. Bovenaan de Pages-pagina verschijnt dan het adres:

    https://<gebruikersnaam>.github.io/werkuren/

## Stap 4 — Op je telefoon

Open dat adres in de browser van je telefoon. Je kunt het toevoegen aan je
beginscherm (in Safari: *Deel → Zet op beginscherm*, in Chrome: *menu →
Toevoegen aan startscherm*). Dan opent hij als een gewone app, zonder
browserbalk, met het KW-icoon.

---

## Belangrijk om te weten

**De uren staan per apparaat.** De app bewaart alles in de browseropslag van
het toestel waarop je werkt. Vul je uren in op je telefoon, dan staan ze niet
automatisch ook op je laptop. Gebruik voorlopig één apparaat, of werk met
dezelfde browser op hetzelfde toestel.

**Wis je browsergegevens niet** zonder erbij na te denken: dan zijn de uren
weg. De app heeft geen reservekopie.

**Een andere repositorynaam?** Dan moet de app opnieuw gebouwd worden met dat
pad, anders laadt hij niet. Vraag het me en ik zet een nieuwe versie klaar.

**Eigen domein?** Dat kan later via Settings → Pages → Custom domain.

---

## Wat er in deze map zit

| Bestand / map | Waarvoor |
|---|---|
| `index.html` | de pagina zelf, met het laadscherm en het logo |
| `main.dart.js` | de hele app |
| `assets/` | logo's, lettertypes, app-gegevens |
| `canvaskit/` | de tekenmodule van Flutter |
| `icons/` | de app-iconen voor je beginscherm |
| `favicon.png` | het tabblad-icoon |
| `manifest.json` | maakt hem installeerbaar als app |
| `.nojekyll` | **verplicht** — zonder dit weigert GitHub Pages bepaalde bestanden |

